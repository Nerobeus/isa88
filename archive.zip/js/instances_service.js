// instances_service.js — Importation des PDF d'instances (LIST OF VARIANTS)
(function (global) {
  const InstanceService = {
    async parseFile(file) {
      console.log("[Instances] Import démarré :", file.name);

      const pdfData = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: pdfData }).promise;

      let foundPage = null;

      // 🔍 Recherche de la bonne page LIST OF VARIANTS avec table
      for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        const fullText = textContent.items.map(it => it.str).join(" ");

        if (/LIST OF VARIANTS/i.test(fullText)) {
          const tree = await page.getStructTree();
          const hasTable = JSON.stringify(tree || {}).includes('"Table"');
          if (hasTable) {
            console.log("[Instances] Table des variants détectée page", pageNum);
            foundPage = page;
            break;
          } else {
            console.log("[Instances] Faux positif LIST OF VARIANTS page", pageNum, "(pas de table)");
          }
        }
      }

      if (!foundPage) {
        console.warn("[Instances] Pas de section LIST OF VARIANTS trouvée, affichage page 1 par défaut");
        return [];
      }

      // Extraire les variants depuis StructTree + mapping mcid
      const rows = await extractVariantsFromStructTree(foundPage);

      console.log("[Instances] Table reconstituée (StructTree+mcid) :", rows);
      rows.forEach((row, i) => {
        console.log(`  → Ligne ${i + 1}:`, row);
      });

      // Mapper en objets variants
      const variants = rows.map((row, idx) => {
        return {
          id: `id_${Math.random().toString(36).substr(2, 8)}_${Date.now()}`,
          variantId: row[0] || "",
          description: row.slice(1).join(" ").trim()
        };
      });

      console.log("[Instances] Variants extraits :", variants);

      // Sauvegarde dans la DB
      await DBService.save("variants", variants);

      return variants;
    }
  };

  // Extraction avec liaison StructTree.id → item textContent
  async function extractVariantsFromStructTree(page) {
    const tree = await page.getStructTree();
    const tc = await page.getTextContent({ disableCombineTextItems: true });

    if (!tree) {
      console.warn("[Instances] Pas de StructTree dispo");
      return [];
    }

    // Construire la map { "pageX_mcidY" : { idx, str } }
    const mcidMap = {};
    tc.items.forEach((it, idx) => {
      const key = `page${page.pageNumber}R_mcid${idx}`;
      mcidMap[key] = { idx, str: (it.str || "").trim() };
      console.log(`[Instances][MapBuild] idx=${idx} key=${key} => "${mcidMap[key].str}"`);
    });
    console.log("[Instances] mcidMap construit (mcid→texte)", mcidMap);

    const rows = [];

    function walk(node, currentRow = []) {
      if (!node) return;
      if (node.role === "TR") {
        currentRow = [];
        node.children?.forEach(child => walk(child, currentRow));
        if (currentRow.length > 0) {
          console.log("[Instances][TR] Ligne construite :", currentRow);
          rows.push(currentRow);
        }
      } else if (node.role === "TD" || node.role === "TH") {
        const cellText = collectContent(node, mcidMap).trim();
        console.log(
          "[Instances][TD] role:", node.role,
          "ids:", node.children?.map(c => c.id || c.role),
          "=>", cellText
        );
        currentRow.push(cellText);
      } else {
        node.children?.forEach(child => walk(child, currentRow));
      }
    }

    walk(tree);
    return rows;
  }

  // 🔹 Fonction récursive pour récupérer tout le contenu d’un TD
  function collectContent(node, mcidMap) {
    let txt = "";
    if (node.type === "content" && mcidMap[node.id]) {
      const entry = mcidMap[node.id];
      console.log(`[Instances][Collect] ${node.id} → idx=${entry.idx}, texte="${entry.str}"`);
      txt += entry.str + " ";
    }
    node.children?.forEach(child => {
      txt += collectContent(child, mcidMap);
    });
    return txt;
  }

  global.InstanceService = InstanceService;
})(window);
