// pid_service.js — Import et affichage PID (overlay synchronisé zoom/pan)
console.log("[DEBUG] pid_service.js chargé");

window.PIDService = (() => {

  async function importPID(file) {
    console.log("[PID] Import démarré :", file.name);

    const tree = document.getElementById("pid-tree");
    if (tree) tree.innerHTML = "";

    const canvas = document.getElementById("pid-canvas");
    if (!canvas) throw new Error("Canvas #pid-canvas introuvable");
    const ctx = canvas.getContext("2d");
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const statusEl = document.getElementById("pid-status");
    if (statusEl) statusEl.textContent = "";

    // ----- PDF -----
    const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
    const page = await pdf.getPage(1);

    const BASE = 2.0;
    const vp = page.getViewport({ scale: BASE });

    // Canvas offscreen
    const off = document.createElement("canvas");
    off.width = vp.width;
    off.height = vp.height;
    await page.render({ canvasContext: off.getContext("2d"), viewport: vp }).promise;

    // Canvas visible
    const wrap = document.querySelector(".canvas-wrap");
    const rect = wrap ? wrap.getBoundingClientRect() : { width: 1000, height: 700 };
    canvas.width = Math.max(800, Math.floor(rect.width));
    canvas.height = Math.max(500, Math.floor(rect.height));

    // ----- Rôles (depuis DB) -----
    const roles = await DBService.getAllRoles();
    const exact = new Map(), nm = new Map(), keys = [];
    const norm = s => (s || "").replace(/\s|[-_\.]/g, "");

    for (const r of roles) {
      for (const k of [(r.TagName || "").trim(), (r.RoleOrSignal || "").trim()]) {
        if (!k) continue;
        exact.set(k, r.EM_ID);
        nm.set(norm(k).toLowerCase(), r.EM_ID);
        keys.push(k);
      }
    }
    const uniq = [...new Set(keys)].sort((a, b) => b.length - a.length);

    // ----- Extraction texte → overlays
    const text = await page.getTextContent();
    const overlays = [];
    const TAG = /[A-Z]{2}\d{3}[A-Z]?[a-z]?/g; // accepte suffixes instances

    for (const it of text.items) {
      const s = String(it.str || "");
      const x = it.transform[4] * BASE;
      const y = it.transform[5] * BASE;

      for (const k of uniq) {
        if (!k) continue;
        if (s.indexOf(k) !== -1) {
          overlays.push({ em: exact.get(k) || "UNMAPPED", tag: k, x, y });
        } else {
          const nx = norm(s).toLowerCase(), nk = norm(k).toLowerCase();
          if (nx.includes(nk)) {
            overlays.push({ em: nm.get(nk) || "UNMAPPED", tag: k, x, y, issue: "Formalisation" });
          }
        }
      }

      let m;
      TAG.lastIndex = 0;
      while ((m = TAG.exec(s)) !== null) {
        const t = m[0];
        const baseTag = t.replace(/[a-z]$/, ""); // retirer suffixe éventuel
        const em = exact.get(baseTag) || nm.get(norm(baseTag).toLowerCase()) || "UNMAPPED";
        overlays.push({ em, tag: t, x, y });
      }
    }

    // ----- Charger EM/CM/Variants depuis DB -----
    const allEms = await DBService.getAll("ems");
    const allCms = await DBService.getAll("cms");
    const allVariants = await DBService.getAll("variants");

    // Organisation des variants par emId
    const variantMap = new Map();
    allVariants.forEach(v => {
      if (!variantMap.has(v.emId)) variantMap.set(v.emId, []);
      variantMap.get(v.emId).push(v);
    });

    // ----- Fonction pour trouver le variant d'une instance -----
    function findVariantFor(emId, detectedCms) {
      const variants = variantMap.get(emId) || [];
      for (const v of variants) {
        const variantSet = new Set(v.cms || []);
        const detectedSet = new Set(detectedCms);

        // exact match
        if (variantSet.size === detectedSet.size &&
            [...detectedSet].every(cm => variantSet.has(cm))) {
          return v.name;
        }

        // subset match (PID incomplet mais cohérent)
        if ([...detectedSet].every(cm => variantSet.has(cm))) {
          return v.name;
        }
      }
      return "V⚠"; // pas trouvé
    }

    // ----- Construire cmsInPid + instances -----
    const tagsInPid = [...new Set(overlays.map(o => o.tag))];
    const cmsInPid = [];
    const emInstances = new Map(); // clé = emId+suffix → { em, suffix, cms: [] }

    for (const cm of allCms) {
      const foundTag = tagsInPid.find(t => t.startsWith(cm.pidTag));
      if (!foundTag) continue;

      const instSuffix = /[a-z]$/.test(foundTag) ? foundTag.slice(-1) : "";
      const key = cm.emId + "|" + instSuffix;
      if (!emInstances.has(key)) {
        const baseEm = allEms.find(e => e.id === cm.emId);
        if (baseEm) {
          emInstances.set(key, {
            ...baseEm,
            id: baseEm.id + (instSuffix ? "_inst_" + instSuffix : ""),
            title: baseEm.title || baseEm.id + (instSuffix ? ` [${instSuffix}]` : ""),
            suffix: instSuffix,
            cms: []
          });
        }
      }
      const inst = emInstances.get(key);
      if (inst) {
        inst.cms.push(cm.pidTag);
        cmsInPid.push({
          ...cm,
          pidTag: foundTag,
          emId: inst.id
        });
      }
    }

    // ----- Attribution des variants -----
    const emsInPid = [];
    for (const inst of emInstances.values()) {
      const baseCms = inst.cms.map(tag => tag.replace(/[a-z]$/, "")); // retirer suffixes
      const variantLabel = findVariantFor(inst.emId.replace(/_inst_.*/, ""), baseCms);
      emsInPid.push({ ...inst, variantLabel });
    }

    if (window.UITree && typeof UITree.build === "function") {
      UITree.build(emsInPid, cmsInPid, "pid-tree");
      console.log("[PID] Arborescence PID construite :", emsInPid.length, "EM/instances /", cmsInPid.length, "CM");
    }

    // ----- Zoom / Pan
    let scale = Math.min(canvas.width / off.width, canvas.height / off.height);
    let panX = (canvas.width - off.width * scale) / 2;
    let panY = (canvas.height - off.height * scale) / 2;
    const MIN = 0.3, MAX = 6;

    function draw() {
      const c = canvas.getContext("2d");
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.clearRect(0, 0, canvas.width, canvas.height);
      c.setTransform(scale, 0, 0, scale, panX, panY);
      c.drawImage(off, 0, 0);
    }

    canvas.addEventListener("wheel", e => {
      e.preventDefault();
      const rc = canvas.getBoundingClientRect();
      const x = (e.clientX - rc.left - panX) / scale;
      const y = (e.clientY - rc.top - panY) / scale;
      const f = e.deltaY < 0 ? 1.1 : 0.9;
      const ns = Math.min(MAX, Math.max(MIN, scale * f));
      panX = e.clientX - rc.left - x * ns;
      panY = e.clientY - rc.top - y * ns;
      scale = ns;
      draw();
      if (window.PIDOverlay) PIDOverlay.refresh();
    }, { passive: false });

    let drag = false, lx = 0, ly = 0;
    canvas.addEventListener("mousedown", e => { drag = true; lx = e.clientX; ly = e.clientY; });
    window.addEventListener("mouseup", () => drag = false);
    window.addEventListener("mousemove", e => {
      if (!drag) return;
      panX += e.clientX - lx;
      panY += e.clientY - ly;
      lx = e.clientX; ly = e.clientY;
      draw();
      if (window.PIDOverlay) PIDOverlay.refresh();
    });

    const resetBtn = document.getElementById("reset-zoom");
    if (resetBtn) {
      resetBtn.onclick = () => {
        scale = Math.min(canvas.width / off.width, canvas.height / off.height);
        panX = (canvas.width - off.width * scale) / 2;
        panY = (canvas.height - off.height * scale) / 2;
        draw();
        if (window.PIDOverlay) PIDOverlay.refresh();
      };
    }

    draw();

    // ----- Overlay
    if (window.PIDOverlay) {
      PIDOverlay.init({
        pdfCanvas: canvas,
        getCMPositions: () => {
          const rBase = 12;
          return overlays.map(o => ({
            cmId: o.tag,
            emId: o.em,
            x: panX + o.x * scale,
            y: panY + (off.height - o.y) * scale,
            r: rBase * scale
          }));
        },
        onHover: cmId => { /* TODO: highlight dans l'arbre P&ID */ },
        onSelect: ids => console.log("[PID] Sélection :", ids),
        getColorForEM: emId => {
          const em = emsInPid.find(e => e.id === emId);
          return em ? em.color : "#39f";
        }
      });
      PIDOverlay.refresh();
    }

    if (statusEl) {
      statusEl.textContent = `Tags détectés: ${overlays.length} — EM/instances: ${emsInPid.length}`;
    }
  }

  return { importPID };
})();
