(function(){
  if (!window.App) window.App = {};
  App.State = App.State || {};
  App.State.state = App.State.state || { emData:{}, emInstances:{}, zoomScale:1, offsetX:0, offsetY:0 };
})();