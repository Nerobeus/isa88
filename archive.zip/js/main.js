// main.js — Orchestrateur principal
console.log("[App] Initialisation");

// Petit helper statut avec auto-clear
function setStatus(id, text, clearMs) {
  const el = document.getElementById(id);
  if (!el) return;
  const token = String(Date.now());
  el.dataset.token = token;
  el.textContent = text || "";
  if (clearMs) {
    setTimeout(() => {
      if (el.dataset.token === token) el.textContent = "";
    }, clearMs);
  }
}

// === Gestion des onglets ===
function initTabs() {
  const tabs = document.querySelectorAll(".tab");
  const panels = document.querySelectorAll(".tab-panel");

  tabs.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabs.forEach((b) => b.classList.remove("active"));
      panels.forEach((p) => p.classList.remove("active"));

      btn.classList.add("active");
      const target = document.querySelector(btn.dataset.target);
      if (target) target.classList.add("active");
    });
  });
}

// === Import Excel ===
function initExcel() {
  const fileInput = document.getElementById("excel-file");
  const filenameLabel = document.getElementById("excel-filename");

  if (!fileInput) return;

  fileInput.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    filenameLabel.textContent = file.name;
    setStatus("excel-status", "Import en cours…");

    try {
      console.log("[Excel] Import démarré :", file.name);

      if (window.ExcelService && typeof ExcelService.importExcelFile === "function") {
        // s’assurer que la DB est bien ouverte pour limiter la latence
        if (window.DBService && typeof DBService.openDB === "function") {
          await DBService.openDB();
        }

        const result = await ExcelService.importExcelFile(file);
        console.log("[Excel] Résultat import :", result);

        // Arborescence Excel → dans #excel-tree
        if (window.UITree && typeof UITree.build === "function") {
          UITree.build(result.ems, result.cms, "excel-tree");
        }

        setStatus("excel-status", "Import terminé ✅", 4000);
      } else {
        console.warn("[Excel] ExcelService.importExcelFile() non trouvé");
        setStatus("excel-status", "Service Excel indisponible ❌", 6000);
      }
    } catch (err) {
      console.error("[Excel] Erreur import :", err);
      setStatus("excel-status", "Erreur à l'import ❌", 6000);
    }
  });
}

// === Import P&ID ===
function initPID() {
  const fileInput = document.getElementById("pid-file");
  const filenameLabel = document.getElementById("pid-filename");
  const resetBtn = document.getElementById("reset-zoom");

  if (!fileInput) return;

  fileInput.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    filenameLabel.textContent = file.name;
    setStatus("pid-status", "Chargement du P&ID…");

    try {
      console.log("[PID] Import démarré :", file.name);

      if (window.PIDService && typeof PIDService.importPID === "function") {
        await PIDService.importPID(file);
        console.log("[PID] Import terminé");
        setStatus("pid-status", "P&ID chargé ✅", 4000);
      } else {
        console.warn("[PID] PIDService.importPID() non trouvé");
        setStatus("pid-status", "Service PID indisponible ❌", 6000);
      }
    } catch (err) {
      console.error("[PID] Erreur import :", err);
      setStatus("pid-status", "Erreur de chargement ❌", 6000);
    }
  });

  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      // compatible avec deux implémentations possibles
      if (window.PIDService && typeof PIDService.resetView === "function") {
        PIDService.resetView();
      } else if (typeof window.resetPIDView === "function") {
        window.resetPIDView();
      }
      console.log("[PID] Réinitialisation de la vue");
    });
  }
}

// === Import Instances ===
function initInstances() {
  const fileInput = document.getElementById("pdf-file");
  const filenameLabel = document.getElementById("pdf-filename");

  if (!fileInput) return;

  fileInput.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    filenameLabel.textContent = file.name;
    setStatus("pdf-status", "Analyse des Instances…");

    try {
      console.log("[Instances] Import démarré :", file.name);

      if (window.InstanceService && typeof InstanceService.parseFile === "function") {
        const result = await InstanceService.parseFile(file);
        console.log("[Instances] Résultat import :", result);

        if (typeof window.renderResults === "function") {
          renderResults(result);
        }

        setStatus("pdf-status", "Instances importées ✅", 4000);
      } else {
        console.warn("[Instances] InstanceService.parseFile() non trouvé");
        setStatus("pdf-status", "Service Instances indisponible ❌", 6000);
      }
    } catch (err) {
      console.error("[Instances] Erreur import :", err);
      setStatus("pdf-status", "Erreur lors de l'analyse ❌", 6000);
    }
  });
}

// === Initialisation générale ===
document.addEventListener("DOMContentLoaded", async () => {
  console.log("[App] DOM prêt");

  // Ouvre la DB au démarrage pour éviter la latence au premier import
  try {
    if (window.DBService && typeof DBService.openDB === "function") {
      await DBService.openDB();
      console.log("[App] DB ouverte au démarrage");
    }
  } catch (e) {
    console.warn("[App] Ouverture DB au démarrage impossible", e);
  }

  initTabs();
  initExcel();
  initPID();
  initInstances();

  console.log("[App] Initialisation terminée");
});
